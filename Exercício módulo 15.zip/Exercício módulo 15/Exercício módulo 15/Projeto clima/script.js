const apiKey = 'b79afc209e80fd1572f818ea7fb5843e';
let distritosCache = [];

async function carregarDistritos() {
    if (distritosCache.length === 0) {
        try {
            const response = await fetch(`https://servicodados.ibge.gov.br/api/v1/localidades/distritos?orderBy=nome`);
            distritosCache = await response.json();
        } catch (error) {
            alert('Erro ao carregar distritos!');
        }
    }
}

async function mostrarSugestoes() {
    const cidade = document.getElementById('cidade').value.toLowerCase();
    const sugestoesDiv = document.getElementById('sugestoes');
    sugestoesDiv.innerHTML = '';

    if (cidade.length > 2) {
        await carregarDistritos(); // Garantir que os distritos foram carregados

        const cidadesFiltradas = distritosCache.filter(distrito =>
            distrito.nome.toLowerCase().includes(cidade)
        );

        if (cidadesFiltradas.length > 0) {
            cidadesFiltradas.forEach(distrito => {
                const item = document.createElement('li');
                item.textContent = distrito.nome;
                item.onclick = () => {
                    document.getElementById('cidade').value = distrito.nome;
                    sugestoesDiv.innerHTML = ''; // Esconder sugestões após seleção
                };
                sugestoesDiv.appendChild(item);
            });
        }
    }
}

async function buscarClima() {
    const cidade = document.getElementById('cidade').value.trim();
    if (!cidade) {
        alert('Digite uma cidade!');
        return;
    }

    try {
        const response = await fetch(`https://api.openweathermap.org/data/2.5/forecast?q=${cidade}&appid=${apiKey}&units=metric&lang=pt`);
        if (!response.ok) throw new Error('Cidade não encontrada');

        const data = await response.json();
        const climaAtual = data.list[0];
        const resultadoAtual = document.getElementById('climaAtual');
        resultadoAtual.innerHTML = `
            <h2>Clima Atual em ${data.city.name}</h2>
            <img class="icon" src="https://openweathermap.org/img/wn/${climaAtual.weather[0].icon}.png" alt="${climaAtual.weather[0].description}" />
            <p class="temp">${climaAtual.main.temp}°C</p>
            <p class="condicao">${climaAtual.weather[0].description}</p>
        `;

        // Previsão para os próximos 5 dias
        const resultado5Dias = document.getElementById('previsao5Dias');
        resultado5Dias.innerHTML = ''; 
        const previsoes = data.list.filter(forecast => forecast.dt_txt.includes("12:00:00"));

        previsoes.forEach(forecast => {
            const dataFormatada = new Date(forecast.dt_txt).toLocaleDateString('pt-BR', {
                weekday: 'short', day: 'numeric', month: 'short'
            });

            resultado5Dias.innerHTML += `
                <div class="previsao">
                    <p class="data">${dataFormatada}</p>
                    <img class="icon" src="https://openweathermap.org/img/wn/${forecast.weather[0].icon}.png" alt="${forecast.weather[0].description}" />
                    <p class="temp-max">Max: ${forecast.main.temp_max}°C</p>
                    <p class="temp-min">Min: ${forecast.main.temp_min}°C</p>
                </div>
            `;
        });

    } catch (error) {
        alert('Erro ao buscar o clima! Verifique o nome da cidade.');
    }
}

// Carregar distritos ao iniciar
carregarDistritos();
