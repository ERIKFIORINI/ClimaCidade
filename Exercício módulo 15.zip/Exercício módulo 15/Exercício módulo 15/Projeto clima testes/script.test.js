import { carregarDistritos, mostrarSugestoes, buscarClima } from './script';

// Mocks
global.fetch = jest.fn(); // Mock do fetch global

beforeEach(() => {
    // Limpar o mock e o DOM antes de cada teste
    fetch.mockClear();
    document.body.innerHTML = `
        <input type="text" id="cidade" />
        <div id="sugestoes"></div>
        <div id="climaAtual"></div>
        <div id="previsao5Dias"></div>
    `;
});

describe('Testando a função carregarDistritos', () => {
    it('Deve carregar distritos e atualizar o cache', async () => {
        // Simular a resposta da API
        fetch.mockResolvedValueOnce({
            json: jest.fn().mockResolvedValue([{ nome: 'São Paulo' }, { nome: 'Rio de Janeiro' }])
        });

        // Executar a função
        await carregarDistritos();

        // Verificar se o distritosCache foi atualizado
        expect(fetch).toHaveBeenCalledTimes(1);
        expect(fetch).toHaveBeenCalledWith('https://servicodados.ibge.gov.br/api/v1/localidades/distritos?orderBy=nome');
    });
});

describe('Testando a função mostrarSugestoes', () => {
    it('Deve mostrar sugestões ao digitar no campo de cidade', () => {
        // Mock de distritosCache
        global.distritosCache = [{ nome: 'São Paulo' }, { nome: 'Rio de Janeiro' }];

        // Definir o valor do campo
        document.getElementById('cidade').value = 'São';

        // Chamar a função de mostrar sugestões
        mostrarSugestoes();

        // Verificar se a sugestão foi adicionada ao DOM
        const sugestoesDiv = document.getElementById('sugestoes');
        expect(sugestoesDiv.children.length).toBe(1);
        expect(sugestoesDiv.children[0].textContent).toBe('São Paulo');
    });
});

describe('Testando a função buscarClima', () => {
    it('Deve buscar o clima e exibir no DOM', async () => {
        // Simular a resposta da API
        fetch.mockResolvedValueOnce({
            json: jest.fn().mockResolvedValue({
                city: { name: 'São Paulo' },
                list: [
                    {
                        weather: [{ icon: '01d', description: 'clear sky' }],
                        main: { temp: 30, temp_max: 35, temp_min: 25 },
                        dt_txt: '2025-02-27 12:00:00'
                    }
                ]
            })
        });

        // Definir o valor do campo de cidade
        document.getElementById('cidade').value = 'São Paulo';

        // Chamar a função para buscar o clima
        await buscarClima();

        // Verificar se o clima atual foi exibido corretamente
        const climaAtual = document.getElementById('climaAtual');
        expect(climaAtual.innerHTML).toContain('Clima Atual em São Paulo');
        expect(climaAtual.innerHTML).toContain('30°C');
        expect(climaAtual.innerHTML).toContain('clear sky');
    });
});